package com.example.pokimon;

public class pokimon {

    String Pokédex ;
    int 48 ;
    int 65 ;
    int 314 ;

    public pokimon(String pokédex) {
        Pokédex = pokédex;
    }

    public String getPokédex() {
        return Pokédex;
    }

    public void setPokédex(String pokédex) {
        Pokédex = pokédex;
    }
}
